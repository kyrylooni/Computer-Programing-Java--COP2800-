
/**
 * Simple demo of class and object
 * @author PaulA
 */
public class EventClass {
        
        
  private String name;
  private int numPeople;
  private double costOfEvent;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumPeople() {
        return numPeople;
    }

    public void setNumPeople(int numPeople) {
        this.numPeople = numPeople;
    }

    public double getCostOfEvent() {
        return costOfEvent;
    }

    public void setCostOfEvent(double costOfEvent) {
        this.costOfEvent = costOfEvent;
    }

  
    
}
