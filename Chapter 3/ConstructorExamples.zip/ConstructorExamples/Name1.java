/**
 * 
 */

/**
 * @author PaulA
 *
 */
public class Name1
{
private String my_name1;

public Name1() // Example of a no - argument constructor

	{
		System.out.println("Constructor method used");
		//my_name1 = "Daytona State College at ATC campus";
	}

/**
 * @return the my_name1
 */
public String getMy_name1() {
	return my_name1;
}

/**
 * @param my_name1 the my_name1 to set
 */
public void setMy_name1(String my_name1) {
	this.my_name1 = my_name1;
}


}
