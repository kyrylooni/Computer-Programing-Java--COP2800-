/**
 * 
 */

/**
 * @author PaulA
 *
 */
public class CollegeTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		College college1 = new College(100, "Daytona State College at Flagler campus"); 
		College college2 = new College(150, "Flageler College");
				// instanstiating an object
		
		System.out.printf("College name is : %s%n", college1.getName());
		
		System.out.println("College age is :" + college1.getAge());
		
System.out.printf("College name is : %s%n", college2.getName());
		
		System.out.println("College age is :" + college2.getAge());
		
				
			
				

	}

}
