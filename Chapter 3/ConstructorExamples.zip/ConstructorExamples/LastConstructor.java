/**
 * 
 */

/**
 * @author PaulA
 *
 */
public class LastConstructor {

	/**
	 * @param args
	 */
	
	String name = "Bethune Cookman";
	
	private LastConstructor() {
		System.out.println ("Inside Constructor");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LastConstructor obj = new LastConstructor();
		

	}

}
