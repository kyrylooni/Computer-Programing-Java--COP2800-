/**
 * 
 */

/**
 * @author PaulA
 *
 */
public class Name1Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Name1 college_campus2 = new Name1();
		college_campus2.setMy_name1("Daytona State College at New Smyrna Beach");
		
		System.out.println("College name is :" + college_campus2.getMy_name1());
	}

}
