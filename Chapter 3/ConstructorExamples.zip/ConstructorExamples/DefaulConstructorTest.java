/**
 * 
 */

/**
 * @author PaulA
 *
 */
public class DefaulConstructorTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultConstructor obj1 = new DefaultConstructor();
		obj1.setID(41528);
		obj1.setCost(1034.555567);
		
		System.out.println("Id is " + obj1.getID());
		System.out.println("Cost is " + obj1.getCost());
		
		
		
	
	}

}
