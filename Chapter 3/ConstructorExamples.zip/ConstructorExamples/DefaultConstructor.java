/**
 * 
 */

/**
 * @author PaulA
 *
 */
public class DefaultConstructor {
	
	private int ID;
	private double cost;
	/**
	 * @return the iD
	 */
	
	/*
	 * 
	 * public DefaultConstructor()
	 * {
	 * 
	 * 
	 * }
	 */
	public int getID() {
		return ID;
	}
	/**
	 * @param iD the iD to set
	 */
	public void setID(int iD) {
		ID = iD;
	}
	/**
	 * @return the cost
	 */
	public double getCost() {
		return cost;
	}
	/**
	 * @param cost the cost to set
	 */
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	

}
