package Shape;

public class ThreeDimensionalShape extends Shape {

    public double radius;

    public void showSphereDimensions() {
        System.out.println("Radius is: " + radius);
    }
}
