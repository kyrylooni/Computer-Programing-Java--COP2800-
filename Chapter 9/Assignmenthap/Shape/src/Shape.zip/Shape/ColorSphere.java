package Shape;

public class ColorSphere extends Sphere {
    public String color;
    public void ShowColor() {
        System.out.println("Color of Sphere is: " + color);
    }
}