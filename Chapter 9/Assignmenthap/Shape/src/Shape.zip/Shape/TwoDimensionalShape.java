package Shape;

public class TwoDimensionalShape extends Shape {
    protected double side;


    public void showSquareDimensions() {
        System.out.println("Width is: " + side);
        System.out.println("Height is: " + side);

    }

}
