package Shape;

public class Square extends TwoDimensionalShape {

    public double Area() {
        return side * side;
    }


}
