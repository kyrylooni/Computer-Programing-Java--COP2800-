package Shape;

public class ColorSquare extends Square {
    public String color;
    public void ShowColor() {

        System.out.println("Color of Square is: " + color);
    }
}
