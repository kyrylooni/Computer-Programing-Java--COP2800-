/**
 * 
 */
package PolymorphismProjct2;

/**
 * @author PaulA
 *
 */
public class TesPattern {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pattern d1 = new Pattern();
	    d1.display();
	    System.out.println("\n");

	    // call method with a single argument
	    d1.display('#');
	}

}
